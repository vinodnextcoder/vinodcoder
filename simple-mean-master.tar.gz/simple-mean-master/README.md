Simple MEAN stack app.

[Live Demo](https://dickeyxxx-simple-mean.herokuapp.com/)

[Blog Post](https://medium.com/@dickeyxxx/mean-how-to-start-cd71d788dd83)
